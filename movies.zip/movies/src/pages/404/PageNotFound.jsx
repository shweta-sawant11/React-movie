import React from 'react'
import "./style.scss";

const pageNotFound = () => {
  return (
    <div>pageNotFound</div>
  )
}

export default pageNotFound